// MI Servo Library
// For ATSAMD11D14A
// Melody Innovation
// August 2021
// Nathan Stanley

#ifndef MISERVO_H_INCLUDED
#define MISERVO_H_INCLUDED

void setupMIservo();
void MIservo(int angle);

#endif
