// MI Servo Library
// For ATSAMD11D14A
// Melody Innovation
// August 2021
// Nathan Stanley

#include "Arduino.h"
#include "MIservo.h"

void setupMIservo()
 {
  REG_GCLK_GENDIV = GCLK_GENDIV_DIV(1) |          // Divide the 48MHz clock source by divisor 1: 48MHz/1=48MHz
                    GCLK_GENDIV_ID(4);            // Select Generic Clock (GCLK) 4
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization

  REG_GCLK_GENCTRL = GCLK_GENCTRL_IDC |           // Set the duty cycle to 50/50 HIGH/LOW
                     GCLK_GENCTRL_GENEN |         // Enable GCLK4
                     GCLK_GENCTRL_SRC_DFLL48M |   // Set the 48MHz clock source
                     GCLK_GENCTRL_ID(4);          // Select GCLK4
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization

  // Enable the port multiplexer for the PWM channel on Pin 4 (physical Pin 20(A3), PA04)
  PORT->Group[g_APinDescription[4].ulPort].PINCFG[g_APinDescription[4].ulPin].bit.PMUXEN = 1;
 
  // Connect the TCC1 timer to the port outputs - port pins are paired odd PMUXO and even PMUXE
  // F & E peripherals specify the timers: TCC0, TCC1 and TCC2
  PORT->Group[g_APinDescription[4].ulPort].PMUX[g_APinDescription[4].ulPin >> 1].reg |= PORT_PMUX_PMUXE_F;

  // Feed GCLK4 to TCC0
  REG_GCLK_CLKCTRL = GCLK_CLKCTRL_CLKEN |         // Enable GCLK4 to TCC0 and TCC1
                     GCLK_CLKCTRL_GEN_GCLK4 |     // Select GCLK4
                     GCLK_CLKCTRL_ID_TCC0;   // Feed GCLK4 to TCC0
  while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for synchronization

  // Normal (single slope) PWM operation: timers countinuously count up to PER register value and then is reset to 0
  REG_TCC0_WAVE |= TCC_WAVE_WAVEGEN_NPWM;        // Setup single slope PWM on TCC1
  while (TCC0->SYNCBUSY.bit.WAVE);                // Wait for synchronization

  // Each timer counts up to a maximum or TOP value set by the PER register,
  // this determines the frequency of the PWM operation: 959999 = 50Hz
  REG_TCC0_PER = 959999;      // Set the frequency of the PWM on TCC1 to 50Hz
  while(TCC0->SYNCBUSY.bit.PER);

  // The CCBx register value corresponds to the pulsewidth in microseconds (us)
  // 90000 is 2.0 ms pulse, 70000 is 1.5 ms pulse, 45000 is 1.0 ms pulse
  REG_TCC0_CC0 = 34000;      // Set the duty cycle of the PWM on TCC0 to 50%
  while(TCC0->SYNCBUSY.bit.CC0);
 
  // Enable TCC1 timer
  REG_TCC0_CTRLA |= TCC_CTRLA_PRESCALER_DIV1 |    // Divide GCLK4 by 1
                    TCC_CTRLA_ENABLE;             // Enable the TCC0 output
  while (TCC0->SYNCBUSY.bit.ENABLE);              // Wait for synchronization
 }
 
 
 void MIservo(int angle)
{
	if(0<=angle<=180){
  int pos = map(angle, 0, 180, 34000, 120000);  // Map the low and high angle range onto the low and high pulse duration range
  REG_TCC0_CC0 = pos;      // Set the duty cycle of the PWM on TCC0
  while(TCC0->SYNCBUSY.bit.CC0);
  delay(1);
	}
	else if(angle>180){
		REG_TCC0_CC0 = 34000;      // Set the duty cycle of the PWM on TCC0
  while(TCC0->SYNCBUSY.bit.CC0);
  delay(1);
	}
}
